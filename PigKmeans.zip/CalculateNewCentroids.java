import java.io.IOException;
import java.util.Iterator;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.BinSedesTuple;
import org.apache.pig.data.InternalCachedBag;
import org.apache.pig.data.Tuple;

/**
 * 
 * a Pig UDF in reducer stage that summaries
 * the assigned centroids into a single record.
 * then emits it as a String in a atomic Tuple
 * 
 * taklwu
 * Feb 7, 2014
 */

public class CalculateNewCentroids extends EvalFunc<String> {
	int numOfPointsInCentroid;
	int dimension = 4;

	
	@Override
	public String exec(Tuple input) throws IOException {
		double[] centroids = new double[this.dimension];
		for (int i = 0; i < this.dimension; i++) {
		    centroids[i] = 0.0;
		}		
        
		// sum all the datapoints assigned to this centroid
		// TODO write your code here
		// hints
		// 1. this loop go through the centroid number, accumlated data points
		// and the assoicated data points count
		// 2. the data point list is structured as (Tuple<centroidNum, x, y, z,
		// count>, Tuple<centroidNum, x, y, z, count>, ....... )
		// 3. we need to take average of all the assoicated data points, then,
		// put it back to double[] centroids
		double clust_count= 0.0;
		double cen_num = 0.0;
		InternalCachedBag icb = (InternalCachedBag) input.get(0);
		Iterator dpiterator = icb.iterator();
      while (dpiterator.hasNext()) {
			BinSedesTuple dataPoint = (BinSedesTuple) dpiterator.next();
			cen_num = Double.valueOf((String) dataPoint.get(0));
			int dimen = 1;
			for (int i = 0; i < dimension - 1; i++) {
				centroids[i] += Double.valueOf((String) dataPoint.get(dimen)) ;
				dimen++;
			}
			clust_count+= Double.valueOf((String) dataPoint.get(dimen)) ;
		}

		if (clust_count!= 0.0) {
			for (int i = 0; i < dimension - 1; i++) {
				centroids[i] /= clust_count;
			}
		}

        
		return this.composeToString(centroids, " ");
	}
	
	public String composeToString (double[] centroids, String split) {
		String result = "";
		for (int i = 0; i < this.dimension; i++) {
			if (i < this.dimension -1 )
				result += centroids[i] + split ;
			else
				result += "0.0";
		}
		return result;
	}
}
