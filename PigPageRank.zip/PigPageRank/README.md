PageRank
========

Page Rank algorithm implementation in pig

${project_dir} = /root/MoocHomeworks/PigPageRank/

Before Compilation (It has been set in VirtualBox VM)
---------------
+  To run Pig in JAVA embeded mode , all the Pig and Hadoop jars have to be available in the java CLASSPATH . Set the classpath as below. Hadoop 1.X may have a different path settings
   + For Hadoop 1.x conf
           export HADOOP_CONF_DIR=$HADOOP_HOME/conf/
           export CLASSPATH=$HADOOP_HOME/lib/*:$HADOOP_HOME/*:$HADOOP_HOME/hadoop-core-1.1.2.jar:$PIG_HOME/lib/*:
           export CLASSPATH=$CLASSPATH:$HADOOP_CONF_DIR:$PIG_HOME/pig-0.14.0-core-h1.jar:.

   + For Yarn (Hadoop 2.x) conf
           export CLASSPATH=$HADOOP_HOME/share/hadoop/common/lib/*:$HADOOP_HOME/share/hadoop/common/*:
           export CLASSPATH=$CLASSPATH:$HADOOP_HOME/share/hadoop/hdfs/*:
           export CLASSPATH=$CLASSPATH:$HADOOP_HOME/share/hadoop/mapreduce/*:$HADOOP_HOME/share/hadoop/https/*:
           export CLASSPATH=$CLASSPATH:$HADOOP_CONF_DIR:$HADOOP_HOME/share/hadoop/yarn/*:$PIG_HOME/pig-0.12.1.jar:.

Compilation
---------------
+ Compile the source files CustomLoader.java, FileUtils.java and PageRank.java under src directory, seal the compiled class into PigPageRank.jar
           
           cd ${project_dir}
           ant clean && ant

Running
---------------
+ Make sure you have started Hadoop correctly.
+ PageRank class two script files . These two scripts need to be available in the same directory of class file .
           
   + **PageRank.pig** - PageRank algorithm implementaion
   + **Rankings.pig** - To write the pagerank values in a seperate file
+ Implement **PageRank.pig**
       replace {fill_your_code} to a working Pig Latin line, hints are provided in the script
	   + TODO calculate new pagerank, generally it should be (1-$dampingFactor) + $dampingFactor * SUM(previous_pagerank.pagerank) as pagerank
	   + you have to check if SUM(previous_pagerank.pagerank) is NULL, if true set it to 0, otherwise just set as is SUM(previous_pagerank.pagerank)
+ This page rank implementation uses custom loader class . This class is compiled into PageRank.jar file . Copy this jar file into HDFS .
       cd ${project_dir}
	   cd bin
       hdfs dfs -copyFromLocal PigPageRank.jar .
+ The input for page rank is available at [SALSA][SALSA] webpage . Download this to your remote server and copy to HDFS . For multiple mappers , split the input file into required partions

       wget http://salsahpc.indiana.edu/csci-p434-fall-2013/apps/PageRankInput/*
       split -l <noOfLines> fileName
	   #default input has 50k input split into two files
	   cd ${project_dir} 
       hdfs dfs -put PigPageRankInput 50kinput

+ PageRank class accepts 5 input parameters
    + noOfUrls - total unique URLs in the input
    + df - damping Factor
    + iter - number of Iterations
    + input - HDFS input directory
    + output - HDFS output directory
    + numberOfReducers - default 2 reducers, otherwise as passed parameters

                      cd ${project_dir}
                      ant clean && ant
                      cd bin
                      java PageRank 50000 0.15 2 50kinput 50krun1 4

+ After the successful execution of the program , Statistics.txt file is generated with statistics of the run.

[server]:https://github.com/abhilashkoppula/PageRank/tree/master/server
[SALSA]:http://salsahpc.indiana.edu/csci-p434-fall-2013/apps/PageRankInput/           

